The script supports two browsers, its recommended to use below browser versions.

Firefox -  version 70.0.1
Chrome - version 78.0.3904.108


This is a maven project & I have parameterized the browser property.

Use below command To run:

"mvn clean test -Dbrowser=Chrome"
"mvn clean test -Dbrowser=Firefox"

Else:

Just double click on the bat file "runtest.bat"


